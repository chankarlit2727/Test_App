from django.contrib import admin

from .models import Link, Movie

admin.site.register(Link)
admin.site.register(Movie)