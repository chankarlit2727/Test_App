from django.shortcuts import redirect, render, get_object_or_404
from django.http import Http404, HttpResponse
from .forms import UploadForm
from .models import Movie
from .models import Link


def home(request):
    return HttpResponse("Ok")

def index(request):
    latest_link_list = Link.objects.order_by('-link_status')
    context = {'latest_link_list': latest_link_list}
    return render(request, 'urlInput/index.html', context)

def detail(request, link_id):
    link = get_object_or_404(Link, pk=link_id)
    return render(request, 'urlInput/detail.html', {'link': link})

def upload(request):
    if request.POST:
        form = UploadForm(request.POST, request.FILES)
        print(request.FILES)
        if form.is_valid():
            form.save()
        return redirect(home)
    return render(request, 'urlInput/upload.html', {'form': UploadForm})

def movie(request, movie_id):
    movie = Movie.objects.get(pk=movie_id)
    if movie is not None:
        return render(request, 'urlInput/movie.html', {'movie' : movie})
    else:
        raise Http404('Movie does not exist')

