from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    # path('<int:link_id>/', views.detail, name='detail'),
    path('<int:movie_id>/', views.movie),
    path('upload/', views.upload, name='upload')
    
]