from django.apps import AppConfig


class UrlinputConfig(AppConfig):
    name = 'urlInput'
